"""quick-conf.app backend."""
